module.exports = {
  x: 10,
  y: 20,
  sumXY: function () {
    return this.x + this.y;
  },
};
