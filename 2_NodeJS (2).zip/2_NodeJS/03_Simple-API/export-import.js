const information = [
  { name: "Harsh", role: "SDE" },
  { name: "Yash", role: "SDE" },
  { name: "Rushi", role: "SDE" },
  { name: "Jill", role: "SDE" },
  { name: "Krisha", role: "SDE" },
  { name: "Belvin", role: "SDE" },
  { name: "Meet", role: "SDE" },
  { name: "Kelvi", role: "SDE" },
];

const university = "Marwadi University";

module.exports = { information, university };
